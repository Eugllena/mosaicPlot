shinyUI(fluidPage(
  titlePanel("Mosaic Plot"),

  sidebarLayout(
    sidebarPanel(
      helpText("Create a mosaic plot with sampled data from the general social survey of Americans."),
      
      selectInput("var",
        label = "Choose a variable to display",
	choices = c("sex", "marital", "health"),
	selected = "sex"),

      checkboxInput("inverse", "Inverse", value = FALSE)
    ),

    mainPanel(plotOutput("plot"))
  )
))