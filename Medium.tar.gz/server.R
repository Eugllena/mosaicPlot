library(ggplot2)
library(productplots)

shinyServer(function(input, output) {

  output$plot = renderPlot({

    f = as.formula(paste("~ happy +", input$var))
    if(input$inverse) f = as.formula(paste("~", input$var, "+ happy"))
    prodplot(happy, f, mosaic(), na.rm = TRUE)

  })
})