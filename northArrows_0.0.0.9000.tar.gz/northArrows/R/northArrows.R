#' Add North Arrows to a Plot
#'
#' Draw north arrows according to a set of points and angles.
#'
#' @param mapping Set of aesthetic mappings created by "aes" or "aes_".
#' 	  If specified and "inherit.aes = TRUE" (the default), it is
#'	  combinded with the default mapping at the top level of the
#'	  plot. You must supply "mapping" if there is no plot mapping.
#' @param data The data to be displayed in this layer. If not be supplied,
#'   	  it will inherit from the plot data as specified in the call to
#'	  "ggplot".
#' @param stat The statistical transformation to use on the data for this
#'        layer, as a string.
#' @param position Position adjustment, either as a string, or the result of #'        a call to a position adjustment function.
#' @param na.rm If ‘FALSE’ (the default), removes missing values with a
#'        warning.  If ‘TRUE’ silently removes missing values.
#' @param show.legned logical. Should this layer be included in the legends?
#'        ‘NA’, the default, includes if any aesthetics are mapped.
#'        ‘FALSE’ never includes, and ‘TRUE’ always includes.
#' @param inherit.aes If ‘FALSE’, overrides the default aesthetics, rather
#' 	  than combining with them.
#' @param length Length of the north arrow shaft.
#' @param angle Angle between the direction of the north arrow and the
#' 	  positive x axis. Angle unit is in radian.
#' @param type One of ‘"open"’ or ‘"closed"’ indicating whether the arrow
#'        head should be a closed triangle.
#' @param ... other arguments passed on to ‘layer’.
#' @author Yongfa Chen, \email{eugllena@@yahoo.com}
#' @seealso \code{\link{"arrows", "grid::arrow"}}
#' @examples
#'
#' dat = data.frame(x=1, y=1)
#' ggplot(dat, aes(x, y)) +
#'   geom_north_arrows(length = 0.5)

GeomNorthArrows <- ggplot2::ggproto("GeomNorthArrows", Geom,
  required_aes = c("x", "y"),
  draw_key = draw_key_path,

  draw_panel = function(data, panel_scales, coord, length, angle, type)
    {
     coords <- coord$transform(data, panel_scales)

     lenSin = length * sin(angle)
     lenCos = length * cos(angle)
     x1 = coords$x
     y1 = coords$y
     x2 = x1 + lenCos
     y2 = y1 + lenSin 
     nx13 = x1 + 0.25 * (x2 - x1)
     ny13 = y1 + 0.25 * (y2 - y1)
     nx24 = x1 + 0.58 * (x2 - x1)
     ny24 = y1 + 0.58 * (y2 - y1)
     nx1 = nx13 + 0.1 * lenSin
     ny1 = ny13 - 0.1 * lenCos
     nx2 = nx24 + 0.1 * lenSin
     ny2 = ny24 - 0.1 * lenCos
     nx3 = nx13 + 0.2 * lenSin
     ny3 = ny13 - 0.2 * lenCos
     nx4 = nx24 + 0.2 * lenSin
     ny4 = ny24 - 0.2 * lenCos
     arrowParams = grid::arrow(length = unit(0.3 * length, "native"), type = type)

     grid::gList(
       grid::segmentsGrob(
         x1, y1, x2, y2,
         arrow = arrowParams,
         gp = grid::gpar(col = coords$colour, lwd = 3, fill = "black")
       ),

       grid::segmentsGrob(
         c(nx1, nx2, nx3), c(ny1, ny2, ny3), c(nx2, nx3, nx4), c(ny2, ny3, ny4),
         gp = grid::gpar(col = coords$colour, lwd = 6)
       )
     )
    }
)

#' @export

geom_north_arrows <- function(mapping = NULL, data = NULL, stat = "identity",
                              position = "identity", na.rm = FALSE,
			      show.legend = NA, inherit.aes = TRUE,
			      length = 1, angle = pi/2, type = "open", ...)
  {
   ggplot2::layer(
     geom = GeomNorthArrows, mapping = mapping,  data = data, stat = stat, 
     position = position, show.legend = show.legend, inherit.aes = inherit.aes,
     params = list(na.rm = na.rm, length = length, angle = angle, type = type, ...)
   )
  }
